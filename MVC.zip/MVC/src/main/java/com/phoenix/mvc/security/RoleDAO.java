package com.phoenix.mvc.security;

import com.phoenix.mvc.db.entities.Role;

public interface RoleDAO {

	public Role getRole(int id);
	
}
