package com.phoenix.mvc.security;

import com.phoenix.mvc.db.entities.Role;

public interface RoleService {

	public Role getRole(int id);
}
